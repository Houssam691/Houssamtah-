from django.contrib import admin
from .models import Category, Product

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'slug']
    search_fields = ['name']
    prepopulated_fields = {'slug': ('name',)}

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ['name', 'category', 'price', 'discount_price', 'stock', 'is_active', 'created_at']
    list_filter = ['category', 'is_active', 'created_at']
    search_fields = ['name', 'description']
    prepopulated_fields = {'slug': ('name',)}
    list_editable = ['price', 'discount_price', 'stock', 'is_active']
    date_hierarchy = 'created_at'
    fieldsets = (
        ('معلومات أساسية', {'fields': ('name', 'slug', 'category', 'description')}),
        ('السعر والمخزون', {'fields': ('price', 'discount_price', 'stock')}),
        ('الصورة والحالة', {'fields': ('image', 'is_active')}),
    )