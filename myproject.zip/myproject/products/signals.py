# signals for products
