from django.db import models
from django.utils.text import slugify

class Category(models.Model):
    name = models.CharField(max_length=100, verbose_name='اسم الفئة')
    slug = models.SlugField(unique=True, blank=True)
    description = models.TextField(blank=True, verbose_name='وصف')
    image = models.ImageField(upload_to='categories/', blank=True, verbose_name='صورة')
    
    class Meta:
        verbose_name = 'فئة'
        verbose_name_plural = 'الفئات'
    
    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        super().save(*args, **kwargs)
    
    def __str__(self):
        return self.name

class Product(models.Model):
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='products', verbose_name='الفئة')
    name = models.CharField(max_length=200, verbose_name='اسم المنتج')
    slug = models.SlugField(unique=True, blank=True)
    description = models.TextField(verbose_name='الوصف')
    price = models.DecimalField(max_digits=10, decimal_places=2, verbose_name='السعر')
    discount_price = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True, verbose_name='سعر الخصم')
    stock = models.PositiveIntegerField(default=0, verbose_name='المخزون')
    image = models.ImageField(upload_to='products/', blank=True, verbose_name='الصورة الرئيسية')
    is_active = models.BooleanField(default=True, verbose_name='نشط')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = 'منتج'
        verbose_name_plural = 'المنتجات'
        ordering = ['-created_at']
    
    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        super().save(*args, **kwargs)
    
    def __str__(self):
        return self.name
    
    @property
    def final_price(self):
        return self.discount_price if self.discount_price else self.price