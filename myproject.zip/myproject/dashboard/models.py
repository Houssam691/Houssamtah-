from django.db import models
# لا توجد نماذج. يستخدم نماذج التطبيقات الأخرى.