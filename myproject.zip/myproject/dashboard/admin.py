from django.contrib import admin
# لا توجد نماذج.