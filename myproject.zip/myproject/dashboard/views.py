from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from orders.models import Order
from products.models import Product
from django.contrib.auth.models import User

@login_required
def dashboard(request):
    total_orders = Order.objects.count()
    total_products = Product.objects.count()
    total_users = User.objects.count()
    recent_orders = Order.objects.order_by('-created_at')[:5]
    
    context = {
        'total_orders': total_orders,
        'total_products': total_products,
        'total_users': total_users,
        'recent_orders': recent_orders,
    }
    return render(request, 'dashboard/index.html', context)