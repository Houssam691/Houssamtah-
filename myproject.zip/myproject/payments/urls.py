from django.urls import path
# سيتم إضافة روابط الدفع لاحقاً

urlpatterns = []