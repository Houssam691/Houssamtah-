from django.db import models
# سيتم إضافة نماذج الدفع لاحقاً عند ربط Stripe/PayPal