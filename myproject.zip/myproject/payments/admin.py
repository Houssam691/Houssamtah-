from django.contrib import admin
# سيتم إضافة إدارة المدفوعات لاحقاً