from django.shortcuts import render
# سيتم إضافة بوابات الدفع لاحقاً