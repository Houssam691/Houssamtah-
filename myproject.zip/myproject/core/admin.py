from django.contrib import admin
# لا توجد نماذج في core حتى الآن