from django.db import models
# لا توجد نماذج في core حتى الآن